const ARRAY_TYPES = {
  UINT_16_ARRAY: 0,
  FLOAT_32_ARRAY: 1,
};

export default ARRAY_TYPES;
