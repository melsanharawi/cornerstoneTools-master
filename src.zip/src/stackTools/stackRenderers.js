import FusionRenderer from './fusionRenderer.js';

const stackRenderers = {};

stackRenderers.FusionRenderer = FusionRenderer;

export default stackRenderers;
